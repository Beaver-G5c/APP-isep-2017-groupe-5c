<?php

require($localisation.'admin/model/admin_mentions_legales_model.php');
require($localisation.'admin/view/admin_mentions_legales_view.php');
?>