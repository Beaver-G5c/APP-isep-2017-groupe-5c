<?php

function footer_website(){ ?>

<footer>

     
     <div id="conteneur-footer">

       <div class="element_footer">©2017 <a href="#">Domisep</a> tous droits réservés </div>


       <div class="element_footer"><a href="#">Confidentialité</a></div>


       <div class="element_footer"><a href="#">Mentions légales</a></div>


       <div class="element_footer"><a href="#">A propos de nous</a></div>


       <div class="element_footer"><a href="index.php?page=website_assistance">Assistance</a></div>

 
       <div class="element_footer"><a href='index.php?page=user_faq'>FAQ</a></div>

      
   </div>
</footer>

<?php } ?>