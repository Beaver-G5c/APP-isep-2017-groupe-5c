<h2> Assistance / Nous contacter </h2>
	<div id = info>
	
		<div class = paragraphe><img class =img src="promo_website/images/phonetest.png" alt="Logo phone" title="Logo phone"/> </div>

		<div class = paragraphe> <a class=lien href='#'>0123456789 </a><br/><br/> Besoin d'aide ? Appelez nous <br/>du Lundi au Samedi de 8h à 20h </div>

		<div class = paragraphe><img class = img src="promo_website/images/dialogue2.png" alt="Logo dialogue" title="Logo dialogue"/></div>
		<div class = paragraphe> <a class=lien href='#'>Chat Domisep</a> <br/> <br/>Conversez avec nos Tele-conseillers <br/>du Lundi au Samedi de 8h à 20h </div>
	</div>
	<div id = info>
		<div class = paragraphe><img class = img src="promo_website/images/mail.png" alt="Logo mail" title="Logo mail"/> </div>
			<div class = paragraphe> <a class=lien href = "mailto:contact.domisep@isep.fr">contact.domisep@isep.fr </a><br/> <br/> Une question, une suggestion,<br/> un problème sur le site ? <br/> Contactez nous.</div>

		<div class = paragraphe><img class = img src="promo_website/images/question.png" alt="Logo question" title="Logo question"/> </div>
			<div class = paragraphe><a class=lien href='index.php?page=user_faq'>FAQ</a> <br/> <br/>Questions fréquement posées : <br/> Ou est passé Charlie ? <br/>Helicoptère ou avion ?</div>
	</div>