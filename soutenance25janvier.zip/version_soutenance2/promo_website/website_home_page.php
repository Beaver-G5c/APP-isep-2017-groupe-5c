 

        

        <div class = encadrement>
            <img src="promo_website/images/promo_top.png" alt="pub" class='pub' title="pub"/> <br><br>
            <p>Adopter Top, un produit domisep, c'est toujours plus</p>
            <div class = promotion>

                <div class = element1>
                    <img src="promo_website/images/img1_pub.png" alt="pub" title="pub"/>
                    
                </div>

                <div class = element1>
                    <img src="promo_website/images/img2_pub.png" alt="pub" title="pub"/>
                    
                </div>

                <div class = element1>
                    <img src="promo_website/images/img3_pub.png" alt="pub" title="pub"/>
                    
                </div>
                 
            </div>

        </div>
        <br>
        <div class = encadrement> 
            <p>Decouvrez de nouveaux produits et fonctionnalites <span>aupres de notre partenaire Domisep !</span></p>
            <div class = catalogue>

                <div class = element2>
                    <img src="promo_website/images/img11_pub.png" alt="pub" title="pub"/> <br/>

                    Achetez votre propre robot de protocole !
                    
                </div>

                <div class = element2>
                    <img src="promo_website/images/img12_pub.png" alt="pub" title="pub"/> <br>
                    Engagez nos esquades de droides !
                    
                </div>

                <div class = element2>
                    <img src="promo_website/images/img13_pub.png" alt="pub" title="pub"/> <br>
                    Investissez dans les rayons X !
                    
                </div>

                <div class = element2>
                    <img src="promo_website/images/img14_pub.png" alt="pub" title="pub"/>
                    Sécurisez vos jardins avec nos Caméra-Nains de jardin !
                    
                </div>

                <div class = element2>
                    <img src="promo_website/images/img15_pub.png" alt="pub" title="pub"/>
                    Renovez votre cuisine !
                    
                </div>



                <div class = element2>
                    <img src="promo_website/images/img16_pub.png" alt="pub" title="pub"/>
                    Adoptez notre fee du menage !
                    
                </div>
                
            </div>
        </div>

        <br><br>
       