<?php 



$_SESSION['statut']='admin';


?>