<?php
/* Author : Thibpffr
version : 1.3
date : 29/11
*/?>
	<form method='POST' action='' class='cadre_connection'>
		<label >Identifiant<input type='text' name='login' placeholder='Ex : Jean28' autofocus required maxlength=255/></label><br/>
		<label> Mot de passe <input type='password' name='password' required maxlength=255/></label>
		<p ><a href='index.php?page=user_forgotten_password'>J'ai oublié mon mot de passe</a></p>
		<label> Valider <input type='submit' name=submit /></label>
		
	</form>
	
	
	
	
	

	
	
	
	 