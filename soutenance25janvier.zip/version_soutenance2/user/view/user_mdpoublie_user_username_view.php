<?php
/* Author : Teva Paquin
version : 1.0
date : 12/12
*/
?>

  
    <h1>Mot de passe oublié</h1>
    <div id='user_name_question'>
        <p> Quel est votre nom d'utilisateur? <br/></p>

        <form method='POST' action=''>
            <label>Réponse : <input type='text' name='reponse' class='reponse' placeholder='Ex:Gontrand'autofocus required maxlength=256/> </label><br>
            <label><input type='submit' name='submit' class='ajout' value='Ajout'/></label>
    
        </form>
       
</div>